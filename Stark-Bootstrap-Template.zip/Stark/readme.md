Stark is a clean entertainment style template

Stark is designed to optimize your reading experience as much as possible. It is easy to modify and use. Stark supports Bootstrap 4, Angular and React.

Features

 - Bootstrap 4
 - Angular & React
 - Bootstrap Mega menu
 - Google Fonts
 - HTML5 & CSS3
 - Easy customizable
 - SEO Optimized
 - Cross browser
 - Smooth Custom scrolling
 - Carousel
 - Subscription Form
 - Customized Angular & React Routing  
 - Customized form validation messages
 - Different colors and font icons
 - Compatible in IE earlier versions

Layouts

 - Boxed
 - Fluid

Pages

 - Home page
 - Bootstrap elements
 - About Us page
 - Error page
 - Base Template for Angular and React

Credits

 - Lato Font
 - Bootstrap Framework v4.x
 - Font Awesome v4.7.0
 - UnSplash Photos


 Keywords

 stark template, bootstrap template, bootstrap angular, bootstrap react, fabric ui templateclinic bootstrap template, corona, Corona virus disease, corona virus prevention, coronavirus, covid, covid-19, covid-19 advises, COVID-19 template, doctors, hospital, medical, medical advises, ncov-2019, responsive, app landing, app showcase template, Application Service, digital marketing landing, next js, parallax, product landing, react, react js, react landing, react template, sass landing, seo, Software Services, web application landing page, admin bootstrap template, admin dashboard bootstrap template, admin template, admin themes, angular bootstrap template, google material design template, laravel bootstrap template, stark bootstrap template, premium bootstrap templates, react template, responsive bootstrap template