<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <title>Elements &ndash; Stark Bootstrap Template</title>
      <?php require("./views/shared/_meta.php"); ?>
   </head>
   <body oncontextmenu="return false;">
    <?php require("./views/shared/_nojs.php"); ?>
      <header class="container px-2 bg-primary shadow">
         <?php require("./views/shared/_header.php"); ?>
      </header>
      <main class="container bg-white shadow">
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
               <li class="breadcrumb-item"><a href="./index">Home</a></li>
               <li class="breadcrumb-item active" aria-current="page">Elements</li>
            </ol>
         </nav>
         <h1 class="display-4 text-primary">Typography</h1>
         <h1 class="text-success">Headings</h1>
         <div class="block">
            <h1>h1. Bootstrap heading</h1>
            <h2>h2. Bootstrap heading</h2>
            <h3>h3. Bootstrap heading</h3>
            <h4>h4. Bootstrap heading</h4>
            <h5>h5. Bootstrap heading</h5>
            <h6>h6. Bootstrap heading</h6>
            <hr/>
            <h1 class="text-success">Display</h1>
            <p class="display-1">Display 1</p>
            <p class="display-2">Display 2</p>
            <p class="display-3">Display 3</p>
            <p class="display-4">Display 4</p>
            <hr/>
            <h2>
               Fancy display heading
               <small class="text-muted">With faded secondary text</small>
            </h2>
            <hr/>
            <h1 class="text-success">Paragraph</h1>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.</p>
         </div>
         <hr/>
         <h1 class="text-success">Lead</h1>
         <p class="lead">
            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu
         </p>
         <h1 class="display-4 text-primary">Panels</h1>
         <div class="row">
            <div class="col-md-4 mt-2 mb-2">
               <div class="panel border bg-white px-2 py-1">
                  <div class="panel-heading bg-light border-bottom text-dark py-1 px-2">
                     <h3 class="panel-title">Default</h3>
                  </div>
                  <div class="panel-body">
                     <p>Lorem ipsum dolor sit a class="text-success"met, mei essent everti theophrastus an, accusam lucilius vis eu. In mei accusamus efficiendi mediocritatem, eos ex paulo complectitur.</p>
                  </div>
               </div>
            </div>
            <div class="col-md-4 mt-2 mb-2">
               <div class="panel bg-white border px-2 py-1">
                  <div class="panel-heading bg-primary text-white py-1 px-2">
                     <h3 class="panel-title">Primary</h3>
                  </div>
                  <div class="panel-body">
                     <p>Lorem ipsum dolor class="text-success" sit amet, mei essent everti theophrastus an, accusam lucilius vis eu. In mei accusamus efficiendi mediocritatem, eos ex paulo complectitur.</p>
                  </div>
               </div>
            </div>
            <div class="col-md-4 mt-2 mb-2">
               <div class="panel bg-white border px-2 py-1">
                  <div class="panel-heading bg-success text-white py-1 px-2">
                     <h3 class="panel-title">Success</h3>
                  </div>
                  <div class="panel-body">
                     <p>Lorem ipsum dolor class="text-success" sit amet, mei essent everti theophrastus an, accusam lucilius vis eu. In mei accusamus efficiendi mediocritatem, eos ex paulo complectitur.</p>
                  </div>
               </div>
            </div>
            <div class="col-md-4 mt-2 mb-2">
               <div class="panel bg-white border px-2 py-1">
                  <div class="panel-heading bg-danger text-white py-1 px-2">
                     <h3 class="panel-title">Danger</h3>
                  </div>
                  <div class="panel-body">
                     <p>Lorem ipsum dolor class="text-success" sit amet, mei essent everti theophrastus an, accusam lucilius vis eu. In mei accusamus efficiendi mediocritatem, eos ex paulo complectitur.</p>
                  </div>
               </div>
            </div>
            <div class="col-md-4 mt-2 mb-2">
               <div class="panel bg-white border px-2 py-1">
                  <div class="panel-heading bg-warning text-white py-1 px-2">
                     <h3 class="panel-title">Warning</h3>
                  </div>
                  <div class="panel-body">
                     <p>Lorem ipsum dolor class="text-success" sit amet, mei essent everti theophrastus an, accusam lucilius vis eu. In mei accusamus efficiendi mediocritatem, eos ex paulo complectitur.</p>
                  </div>
               </div>
            </div>
            <div class="col-md-4 mt-2 mb-2">
               <div class="panel bg-white border px-2 py-1">
                  <div class="panel-heading bg-danger text-white py-1 px-2">
                     <h3 class="panel-title">Danger</h3>
                  </div>
                  <div class="panel-body">
                     <p>Lorem ipsum dolor class="text-success" sit amet, mei essent everti theophrastus an, accusam lucilius vis eu. In mei accusamus efficiendi mediocritatem, eos ex paulo complectitur.</p>
                  </div>
               </div>
            </div>
         </div>
         <h1 class="display-4 text-primary">Buttons</h1>
         <section class="container-fluid px-2 py-4">
            <div class="col-md-6">
               <h2>Basic Buttons</h2>
               <div class="block">
                  <button type="button" class="btn btn-default">Default</button>
                  <button type="button" class="btn btn-primary">Primary</button>
                  <button type="button" class="btn btn-success">Success</button>
                  <button type="button" class="btn btn-info">Info</button>
                  <button type="button" class="btn btn-warning">Warning</button>
                  <button type="button" class="btn btn-danger">Danger</button>
               </div>
               <h2>Ada Buttons</h2>
               <div class="block">
                  <button type="button" class="btn btn-ada-light">Light</button>
                  <button type="button" class="btn btn-ada-dark">Dark</button>
               </div>
               <h2>Buttons Group</h2>
               <div class="block">
                  <div class="btn-group">
                     <button type="button" class="btn btn-default">Left</button>
                     <button type="button" class="btn btn-default">Middle</button>
                     <button type="button" class="btn btn-default">Right</button>
                  </div>
               </div>
               <h2>Buttons Nesting</h2>
               <div class="block">
                  <div class="btn-group">
                     <button type="button" class="btn btn-default">1</button>
                     <button type="button" class="btn btn-default">2</button>
                     <div class="btn-group">
                        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                        Dropdown
                        <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu">
                           <li><a href="#">Dropdown link</a></li>
                           <li><a href="#">Dropdown link</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <h2>Split Buttons</h2>
               <div class="block">
                  <div class="btn-group">
                     <button type="button" class="btn btn-primary">Action</button>
                     <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                     <span class="caret"></span>
                     <span class="sr-only">Toggle Dropdown</span>
                     </button>
                     <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Another action</a></li>
                        <li><a href="#">Something else here</a></li>
                        <li class="divider"></li>
                        <li><a href="#">Separated link</a></li>
                     </ul>
                  </div>
               </div>
               <h2>Dropdown Buttons</h2>
               <div class="block">
                  <div class="btn-group">
                     <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                     Action <span class="caret"></span>
                     </button>
                     <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Another action</a></li>
                        <li><a href="#">Something else here</a></li>
                        <li class="divider"></li>
                        <li><a href="#">Separated link</a></li>
                     </ul>
                  </div>
                  <!-- Single button -->
                  <div class="btn-group">
                     <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                     Action <span class="caret"></span>
                     </button>
                     <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Another action</a></li>
                        <li><a href="#">Something else here</a></li>
                        <li class="divider"></li>
                        <li><a href="#">Separated link</a></li>
                     </ul>
                  </div>
               </div>
            </div>
            <!-- /.col-md-6 -->
            <div class="col-md-6">
               <h2>Buttons Sizes</h2>
               <div class="block">
                  <p>
                     <button type="button" class="btn btn-primary btn-lg">Large button</button>
                     <button type="button" class="btn btn-default btn-lg">Large button</button>
                  </p>
                  <p>
                     <button type="button" class="btn btn-primary">Default button</button>
                     <button type="button" class="btn btn-default">Default button</button>
                  </p>
                  <p>
                     <button type="button" class="btn btn-primary btn-sm">Small button</button>
                     <button type="button" class="btn btn-default btn-sm">Small button</button>
                  </p>
                  <p>
                     <button type="button" class="btn btn-primary btn-xs">Extra small button</button>
                     <button type="button" class="btn btn-default btn-xs">Extra small button</button>
                  </p>
               </div>
               <h2>Block Buttons</h2>
               <div class="block">
                  <button type="button" class="btn btn-primary btn-lg btn-block">Block level button</button>
                  <button type="button" class="btn btn-default btn-lg btn-block">Block level button</button>
               </div>
               <h2>Justified Buttons</h2>
               <div class="block">
                  <div class="btn-group btn-group-justified">
                     <div class="btn-group">
                        <button type="button" class="btn btn-primary">Left</button>
                     </div>
                     <div class="btn-group">
                        <button type="button" class="btn btn-primary">Middle</button>
                     </div>
                     <div class="btn-group">
                        <button type="button" class="btn btn-primary">Right</button>
                     </div>
                  </div>
               </div>
               <h2>Buttons With Icons</h2>
               <div class="block">
                  <button type="button" class="btn btn-primary"><i class="fa fa-cog"></i> Button</button>
                  <button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Button</button>
                  <button type="button" class="btn btn-primary"><i class="fa fa-heart"></i> Button</button>
               </div>
            </div>
         </section>
         <h1 class="display-4 text-primary">Tables</h1>
         <section class="px-2 py-4">
            <h2>Basic Table</h2>
            <div class="block">
              <table class="table">
                <caption>Optional table caption.</caption>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Username</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                  </tr>
                  <tr>
                    <th scope="row">2</th>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                  </tr>
                  <tr>
                    <th scope="row">3</th>
                    <td>Larry</td>
                    <td>the Bird</td>
                    <td>@twitter</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h2>Striped Table</h2>
            <div class="block">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Username</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                  </tr>
                  <tr>
                    <th scope="row">2</th>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                  </tr>
                  <tr>
                    <th scope="row">3</th>
                    <td>Larry</td>
                    <td>the Bird</td>
                    <td>@twitter</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h2>Bordered Table</h2>
            <div class="block">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Username</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                  </tr>
                  <tr>
                    <th scope="row">2</th>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                  </tr>
                  <tr>
                    <th scope="row">3</th>
                    <td>Larry</td>
                    <td>the Bird</td>
                    <td>@twitter</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h2>Hover rows</h2>
            <div class="block">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Username</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                  </tr>
                  <tr>
                    <th scope="row">2</th>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                  </tr>
                  <tr>
                    <th scope="row">3</th>
                    <td>Larry</td>
                    <td>the Bird</td>
                    <td>@twitter</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h2>Condensed table</h2>
            <div class="block">
              <table class="table table-condensed">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Username</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                  </tr>
                  <tr>
                    <th scope="row">2</th>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                  </tr>
                  <tr>
                    <th scope="row">3</th>
                    <td colspan="2">Larry the Bird</td>
                    <td>@twitter</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h2>Contextual classes</h2>
            <div class="block">
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Column heading</th>
                    <th>Column heading</th>
                    <th>Column heading</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="active">
                    <th scope="row">1</th>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr>
                    <th scope="row">2</th>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr class="success">
                    <th scope="row">3</th>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr>
                    <th scope="row">4</th>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr class="bg-info">
                    <th scope="row">5</th>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr>
                    <th scope="row">6</th>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr class="bg-warning">
                    <th scope="row">7</th>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr>
                    <th scope="bg-row">8</th>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                  <tr class="bg-danger">
                    <th scope="row">9</th>
                    <td>Column content</td>
                    <td>Column content</td>
                    <td>Column content</td>
                  </tr>
                </tbody>
              </table>
            </div>
         </section>
         <h1 class="display-4 text-primary">Form</h1>
         <section class="px-2 py-1">
            <h2>Form Elements</h2>
            <div class="block">
              <form class="form-horizontal style-form" method="get">
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Default</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Help text</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control">
                        <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Rounder</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control round-form">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Input focus</label>
                    <div class="col-sm-10">
                        <input class="form-control" id="focusedInput" type="text" value="This is focused...">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Disabled</label>
                    <div class="col-sm-10">
                        <input class="form-control" id="disabledInput" type="text" placeholder="Disabled input here..." disabled="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Placeholder</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" placeholder="placeholder">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Password</label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control" placeholder="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-2 col-sm-2 control-label">Static control</label>
                    <div class="col-lg-10">
                        <p class="form-control-static">email@example.com</p>
                    </div>
                </div>
              </form>
            </div>

            <h2>Inline Form</h2>
            <div class="block">
              <form class="form-inline" role="form">
                <div class="form-group">
                    <label class="sr-only" for="exampleInputEmail2">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail2" placeholder="Enter email">
                </div>
                <div class="form-group">
                    <label class="sr-only" for="exampleInputPassword2">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword2" placeholder="Password">
                </div>
                <button type="submit" class="btn btn-theme">Sign in</button>
              </form>

            </div>

            <h2>Input Messages</h2>
            <div class="block">
              <form class="form-horizontal tasi-form" method="get">
                <div class="form-group has-success">
                    <label class="col-sm-2 control-label col-lg-2" for="inputSuccess">Input with success</label>
                    <div class="col-lg-10">
                        <input type="text" class="form-control" id="inputSuccess">
                    </div>
                </div>
                <div class="form-group has-warning">
                    <label class="col-sm-2 control-label col-lg-2" for="inputWarning">Input with warning</label>
                    <div class="col-lg-10">
                        <input type="text" class="form-control" id="inputWarning">
                    </div>
                </div>
                <div class="form-group has-error">
                    <label class="col-sm-2 control-label col-lg-2" for="inputError">Input with error</label>
                    <div class="col-lg-10">
                        <input type="text" class="form-control" id="inputError">
                    </div>
                </div>
              </form>
            </div>

            <h2>Checkboxes, Radios &amp; Selects</h2>
            <div class="block">
              <div class="checkbox">
                <label>
                  <input type="checkbox" value="">
                  Option one is this and that—be sure to include why it's great
                </label>
              </div>
              
              <div class="radio">
                <label>
                  <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked="">
                  Option one is this and that—be sure to include why it's great
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">
                  Option two can be something else and selecting it will deselect option one
                </label>
              </div>
              
              <hr>
              <label class="checkbox-inline">
                <input type="checkbox" id="inlineCheckbox1" value="option1"> 1
              </label>
              <label class="checkbox-inline">
                <input type="checkbox" id="inlineCheckbox2" value="option2"> 2
              </label>
              <label class="checkbox-inline">
                <input type="checkbox" id="inlineCheckbox3" value="option3"> 3
              </label>
              
              <hr>
              <select class="form-control">
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </select>
              <br>
              <select multiple="" class="form-control">
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </select>
            </div>
            <div class="block">
                <h2 class="text-success">Custom</h2>
                <div class="form-group">
                  <div class="custom-control custom-radio">
                    <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input" checked="">
                    <label class="custom-control-label" for="customRadio1">Toggle this custom radio</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                    <label class="custom-control-label" for="customRadio2">Or toggle this other custom radio</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input type="radio" id="customRadio3" name="customRadio" class="custom-control-input" disabled="">
                    <label class="custom-control-label" for="customRadio3">Disabled custom radio</label>
                  </div>
                </div>
              </div>
         </section>
      </main>
      <footer class="container mt-0 px-2">
         <?php require("./views/shared/_footer.php"); ?>
      </footer>
      <?php require("./views/shared/_scripts.php"); ?>
   </body>
</html>