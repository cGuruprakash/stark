<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <title>About Us &ndash; Stark Bootstrap Template</title>
    <?php require("./views/shared/_meta.php"); ?>
</head>
<body oncontextmenu="return false;">
    <?php require("./views/shared/_nojs.php"); ?>
    <header class="container px-2 bg-primary shadow">
        <?php require("./views/shared/_header.php"); ?>
    </header>
    <main class="container bg-white shadow">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="./index">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">About Us</li>
          </ol>
        </nav>
        <div class="post">

          <div class="caption">
            <div class="header py-4">
            	<div class="media">
				  <img src="./assets/images/2.jpg" style="width: 120px; height: 100px" class="mr-3 rounded" alt="./assets/images/2.jpg">
				  <div class="media-body">
				    <h5 class="mt-0 display-4">About Us</h5>
				    <a href="#" class="mr-2"><span class="fa fa-facebook"></span></a>
				    <a href="#" class="mr-2"><span class="fa fa-twitter"></span></a>
				    <a href="#" class="mr-2"><span class="fa fa-pinterest"></span></a>
				  </div>
				</div>
            </div>

            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque <a href="#">penatibus</a> et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, <strong>pretium quis, sem.</strong></p>

            <p>Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.</p>

            <p><strong>Aliquam lorem ante</strong>, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. <strong>Etiam rhoncus</strong>. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante <a href="#">tincidunt tempus</a>.</p>

            <blockquote>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
            </blockquote>

            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, <a href="#">nascetur ridiculus</a> mus. Donec quam felis, ultricies nec, pellentesque eu, <strong>pretium quis, sem.</strong></p>

            <div class="row">
              <div class="col-md-4">
                <ul>
                  <li>Donec quam felis</li>
                  <li>Consectetuer adipiscing</li>
                </ul>
              </div>
              <div class="col-md-4">
                <ul>
                  <li>Donec quam felis</li>
                  <li>Consectetuer adipiscing</li>
                </ul>
              </div>
              <div class="col-md-4">
                <ul>
                  <li>Donec quam felis</li>
                  <li>Consectetuer adipiscing</li>
                </ul>
              </div>
            </div>

            <p>Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. <strong>Etiam rhoncus</strong>. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante <a href="#">tincidunt tempus</a>.</p>

          </div>
        </div>
    </main>
    <footer class="container mt-0 px-2">
        <?php require("./views/shared/_footer.php"); ?>
    </footer>
    <?php require("./views/shared/_scripts.php"); ?>
</body>
</html>