<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <title>Codeculous. &ndash; Learn Share &amp; Accelerate</title>
    <?php require("./views/shared/_meta.php"); ?>
</head>
<body oncontextmenu="return false;">
    <header>
        <?php require("./views/shared/_header.php"); ?>
    </header>
    <main>
        <?php require("./views/shared/_subscription.php"); ?>
    </main>
    <footer>
        <?php require("./views/shared/_footer.php"); ?>
    </footer>
    <?php require("./views/shared/_scripts.php"); ?>
</body>

</html>