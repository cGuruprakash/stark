<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <title>Stark Bootstrap Template &ndash; L&aelig;rer Labs</title>
    <?php require("./views/shared/_meta.php"); ?>
</head>
<body oncontextmenu="return false;">
    <?php require("./views/shared/_nojs.php"); ?>
    <header class="container px-2 bg-primary shadow">
        <?php require("./views/shared/_header.php"); ?>
    </header>
    <main class="container bg-white shadow">
        <?php require("./views/shared/_banner.php"); ?>
        <?php require("./views/shared/_featured.php"); ?>
        <section class="bg-blue pt-3 pb-3 mt-4 subscription" style="background: url('./assets/subscription.jpeg') no-repeat !important;">
            <?php require("./views/shared/_subscription.php"); ?>
        </section>
    </main>
    <footer class="container mt-0 px-2">
        <?php require("./views/shared/_footer.php"); ?>
    </footer>
    <?php require("./views/shared/_scripts.php"); ?>
</body>
</html>