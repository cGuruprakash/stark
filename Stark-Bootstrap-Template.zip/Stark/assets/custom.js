$(document).ready(function () {
    $('#action_menu_btn').click(function(){
        debugger;
        $('.action_menu').toggle();
    });
    $("body").tooltip({ selector: '[data-toggle=tooltip]' });
    //$('.badge').popover('toggle');
    
    $('a.ply-lnk').click(function(){
        var idx = $('a.ply-lnk').index(this);
        SetActive(idx);
        var poster = $(this).data('poster');
        var src = $(this).data('src');

        $('#plyr').attr('poster',poster);
        var chunks = src.replace('http://','').replace('https://','').split(/[/?#]/)[0];
        if(chunks != undefined && chunks != ''){
            switch (chunks) {
                case 'youtube.com':
                case 'www.youtube.com':
                        id = src.split("=")[1];
                        $('video#plyr').get(0).removeAttr('data-vimeo-id')
                                              .attr('data-youtube-id',id);        
                    break;
                case 'www.vimeo.com':
                case 'vimeo.com':    
                        id = src.replace("www.","").replace("https://vimeo.com","codeculous:").split("/")[1];
                        $('video#plyr').get(0).removeAttr('data-youtube-id')
                                              .attr('data-vimeo-id',id);        
                    break;
                default:
                        $('video#plyr').get(0).source = src;        
                    break;
            };
            console.log($('video#plyr').get(0));
        }
        else{
            $('video#plyr').get(0).source = "";
            $('video#plyr').get(0).load();
        }  
        $('video#plyr').get(0).load();
        alert($('video#plyr').get(0).attr('src'));
        $('video#plyr').get(0).play(); 
    });
    function SetActive(idx){
        $('ul.contacts li').each(function() {
            $(this).removeClass('active');
        });
        $('ul.contacts li:eq('+idx+')').addClass('active');
    }
});