<?php
error_reporting(0);
header('Location: ../index');