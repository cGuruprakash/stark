<?php 
 $pg = basename($_SERVER['PHP_SELF']);;
 if($pg != 'search.php'){
?>
<div class="row mx-auto w-75 px-5 py-5 bg-white shadow-lg">
    <section class="col-md-6">
        <span class="fa fa-envelope-o text-primary fa-5x mb-4"></span>
        <h3>Stay in touch with Stark</h3>
        <p>
            Sign up to the stark newsletter and be the first one to know about new videos or special offers.
        </p>
    </section>
    <section class="col-md-6">
    <form class="form">
        <div class="col-md-12 form-group">
            <label for="userName">Name</label>
            <input type="text" class="form-control" id="userName" oninvalid="this.setCustomValidity('Please enter your full name')" oninput="this.setCustomValidity('')" required/>
        </div>
        <div class="col-md-12 form-group">
            <label for="userEmail">Email address</label>
            <input type="email" class="form-control" id="userEmail" oninvalid="this.setCustomValidity('Please enter your email address')" oninput="this.setCustomValidity('')" aria-describedby="emailHelp" required/>
            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <div class="col-md-12 mb-3 mt-1">
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">
                    Also make me as a <span class="badge badge-primary"  data-toggle="tooltip" data-placement="top" title="Upload your videos and earn $5, for more info read the T&amp;C" ><span class="fa fa-user mr-1"></span>Contributor<span>
                </label>
            </div>
            <button type="submit" class="btn btn-outline-primary btn-block"><span class="fa fa-envelope-o mr-2"></span>Subscribe Us</button>
        </div>
    </form>
    </section>
</div>
<?php 
 }
?>