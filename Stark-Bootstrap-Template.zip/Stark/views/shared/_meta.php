<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="shortcut icon" href="./assets/favicon.ico" />
<meta name="theme-color" content="#001628">
<meta name="author" content="@guruprakashc"/>
<meta name="description" content="Stark is designed to optimize your reading experience as much as possible. It is easy to modify and use. Stark supports Bootstrap 4, Angular and React."/>
<meta name="keywords" content="stark template, bootstrap template, bootstrap angular, bootstrap react, fabric ui templateclinic bootstrap template, corona, Corona virus disease, corona virus prevention, coronavirus, covid, covid-19, covid-19 advises, COVID-19 template, doctors, hospital, medical, medical advises, ncov-2019, responsive, app landing, app showcase template, Application Service, digital marketing landing, next js, parallax, product landing, react, react js, react landing, react template, sass landing, seo, Software Services, web application landing page, admin bootstrap template, admin dashboard bootstrap template, admin template, admin themes, angular bootstrap template, google material design template, laravel bootstrap template, stark bootstrap template, premium bootstrap templates, react template, responsive bootstrap template"/>
<meta property="og:title" content="Stark Bootstrap Template" />
<meta property="og:description" content="Stark is designed to optimize your reading experience as much as possible. It is easy to modify and use. Stark supports Bootstrap 4, Angular and React." />
<meta property="og:image" content="./assets/images/stark-template-laererlabs.png" />
<meta property="og:locale" content="en_US" />

<link rel="stylesheet" href="./assets/bootstrap.css" />
<link rel="stylesheet" href="./assets/theme.css">
<link rel="stylesheet" href="./assets/style.css">
<link rel="stylesheet" href="./assets/scroll.css">
<link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />