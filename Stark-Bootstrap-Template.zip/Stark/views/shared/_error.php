<div class="jumbotron jumbotron-fluid text-center bg-light">
  <h1 class="display-4">404</h1>
  <p class="lead">That's an error!</p>
  <hr class="my-4">
  <p>The requested URL was not found on this server.</p>
  <p class="lead">
    <a class="btn btn-primary btn-lg" href="./index" role="button">Go to Home<span class="fa fa-home ml-2"></span></a>
  </p>
</div>