<noscript>
	<div class="bg-info text-white px-3 py-3">
		<p class="lead"><span class="h3">Please enable javscript in your browser.</span><br/>Please click the below link to know</p>
		<p>How to <a href="https://www.enable-javascript.com/" rel="external" class="btn btn-sm btn-success" target="_blank">enable</a> javascript in your browser?</p>
		<style>header,main,footer{ display: none; }</style>
	</div>
</noscript>