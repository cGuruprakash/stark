<article class="container-fluid">
    <h3>Featured Videos</h3>
    <section class="row">
        <div class="col-md-4 article mx-auto mt-2 mb-3">
            <article class="card mb-3 shadow">
                <div class="row no-gutters">
                    <div class="col-md-5">
                        <img src="./assets/images/6.jpg" class="card-img h-100" alt="...">
                    </div>
                    <div class="col-md-7">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a wider card with supporting text below as a
                                natural lead-in to additional content. This content is a little bit
                                longer.</p>
                            <p class="card-text"><small class="text-muted">Last updated 3 mins
                                    ago</small></p>
                        </div>
                    </div>
                </div>
            </article>
        </div>
        <div class="col-md-4 article mx-auto mt-2 mb-3">
            <article class="card mb-3 shadow">
                <div class="row no-gutters">
                    <div class="col-md-5">
                        <img src="./assets/images/4.jpg" class="card-img h-100" alt="...">
                    </div>
                    <div class="col-md-7">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a wider card with supporting text below as a
                                natural lead-in to additional content. This content is a little bit
                                longer.</p>
                            <p class="card-text"><small class="text-muted">Last updated 3 mins
                                    ago</small></p>
                        </div>
                    </div>
                </div>
            </article>
        </div>
        <div class="col-md-4 article mx-auto mt-2 mb-3">
            <article class="card mb-3 shadow">
                <div class="row no-gutters">
                    <div class="col-md-5">
                        <img src="./assets/images/5.jpg" class="card-img h-100" alt="...">
                    </div>
                    <div class="col-md-7">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a wider card with supporting text below as a
                                natural lead-in to additional content. This content is a little bit
                                longer.</p>
                            <p class="card-text"><small class="text-muted">Last updated 3 mins
                                    ago</small></p>
                        </div>
                    </div>
                </div>
            </article>
        </div>
        <div class="col-md-4 article mx-auto mt-2 mb-3">
            <article class="card mb-3 shadow">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="./assets/images/4.jpg" class="card-img" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a wider card with supporting text below as a
                                natural lead-in to additional content. This content is a little bit
                                longer.</p>
                            <p class="card-text"><small class="text-muted">Last updated 3 mins
                                    ago</small></p>
                        </div>
                    </div>
                </div>
            </article>
        </div>
        <div class="col-md-4 article mx-auto mt-2 mb-3">
            <article class="card mb-3 shadow">
                <div class="row no-gutters">
                    <div class="col-md-5">
                        <img src="./assets/images/5.jpg" class="card-img h-100" alt="...">
                    </div>
                    <div class="col-md-7">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a wider card with supporting text below as a
                                natural lead-in to additional content. This content is a little bit
                                longer.</p>
                            <p class="card-text"><small class="text-muted">Last updated 3 mins
                                    ago</small></p>
                        </div>
                    </div>
                </div>
            </article>
        </div>
        <div class="col-md-4 article mx-auto mt-2 mb-3">
            <article class="card mb-3 shadow">
                <div class="row no-gutters">
                    <div class="col-md-5">
                        <img src="./assets/images/6.jpg" class="card-img h-100" alt="...">
                    </div>
                    <div class="col-md-7">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a wider card with supporting text below as a
                                natural lead-in to additional content. This content is a little bit
                                longer.</p>
                            <p class="card-text"><small class="text-muted">Last updated 3 mins
                                    ago</small></p>
                        </div>
                    </div>
                </div>
            </article>
        </div>
    </section>
    <section class="row mt-3">
        <div class="col-md-12 mx-auto mt-2 mb-2 text-center">
            <a href="#" class="btn btn-success btn-primary">Browse all Videos<span
                    class="fa fa-arrow-right ml-3"></span></a>
        </div>
    </section>
</article>
<article class="container-fluid">
    <h3>Featured Resources</h3>
    <div class="row">
        <section class="col-md-3">
            <div class="nav flex-column nav-pills resources" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <a class="nav-link active" id="v-pills-templates-tab" data-toggle="pill" href="#v-pills-templates" role="tab"
                    aria-controls="v-pills-templates" aria-selected="true">Templates</a>
                <a class="nav-link" id="v-pills-stimgs-tab" data-toggle="pill" href="#v-pills-stimgs" role="tab"
                    aria-controls="v-pills-stimgs" aria-selected="false">Stock Photos</a>
                <a class="nav-link" id="v-pills-media-tab" data-toggle="pill" href="#v-pills-media" role="tab"
                    aria-controls="v-pills-media" aria-selected="false">Videos/Audios</a>
                <a class="nav-link" id="v-pills-addplug-tab" data-toggle="pill" href="#v-pills-addplug" role="tab"
                    aria-controls="v-pills-addplug" aria-selected="false">Plugins/Addons</a>
                <a class="nav-link" id="v-pills-softwares-tab" data-toggle="pill" href="#v-pills-softwares" role="tab"
                    aria-controls="v-pills-softwares" aria-selected="false">Softwares</a>
            </div>
        </section>
        <section class="col-md-9">
            <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="v-pills-templates" role="tabpanel"
                    aria-labelledby="v-pills-templates-tab">
                    Themes/Templates
                </div>
                <div class="tab-pane fade" id="v-pills-stimgs" role="tabpanel" aria-labelledby="v-pills-stimgs-tab">
                    Photos
                </div>
                <div class="tab-pane fade" id="v-pills-media" role="tabpanel" aria-labelledby="v-pills-media-tab">
                    Videos & Audios
                </div>
                <div class="tab-pane fade" id="v-pills-addplug" role="tabpanel" aria-labelledby="v-pills-addplug-tab">
                    Plugins & Add-ons
                </div>
                <div class="tab-pane fade" id="v-pills-softwares" role="tabpanel" aria-labelledby="v-pills-softwares-tab">
                    Softwares
                </div>
            </div>
        </section>
    </div>
</article>