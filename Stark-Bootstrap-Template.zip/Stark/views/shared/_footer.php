<?php 
 $pg = basename($_SERVER['PHP_SELF']);
 if($pg != 'search.php'){
?>
<div class="row mx-auto pt-3 pb-0">
    <section class="col-md-3">
        <h5 class="text-info">About</h5>
        <ul class="list-unstyled text-small">
            <li><a class="text-hover-white" href="#">About</a></li>
            <li><a class="text-hover-white" href="#">Certificates</a></li>
            <li><a class="text-hover-white" href="#">Careers</a></li>
            <li><a class="text-hover-white" href="#">Contribution</a></li>
        </ul>
    </section>
    <section class="col-md-3">
        <h5 class="text-info">Community</h5>
        <ul class="list-unstyled text-small">
            <li><a class="text-hover-white" href="#">Learners</a></li>
            <li><a class="text-hover-white" href="#">Partners</a></li>
            <li><a class="text-hover-white" href="#">Stuff for Developers</a></li>
            <li><a class="text-hover-white" href="#">Blog</a></li>
            <li><a class="text-hover-white" href="#">Donate</a></li>
        </ul>
    </section>
    <section class="col-md-3">
        <h5 class="text-info">Resources</h5>
        <ul class="list-unstyled text-small">
            <li><a class="text-hover-white" href="#">Web Templates</a></li>
            <li><a class="text-hover-white" href="#">Royality free images</a></li>
            <li><a class="text-hover-white" href="#">Background Musics/Videos</a></li>
            <li><a class="text-hover-white" href="#">Plugins/Addons</a></li>
        </ul>
    </section>
    <section class="col-md-3">
        <h5 class="text-info">Features</h5>
        <ul class="list-unstyled text-small">
            <li><a class="text-hover-white" href="#">Cool stuff</a></li>
            <li><a class="text-hover-white" href="#">Random feature</a></li>
            <li><a class="text-hover-white" href="#">Team feature</a></li>
            <li><a class="text-hover-white" href="#">Stuff for developers</a></li>
            <li><a class="text-hover-white" href="#">Another one</a></li>
            <li><a class="text-hover-white" href="#">Last time</a></li>
        </ul>
    </section>
</div>
<?php 
 }
?>
<div class="row copy mx-auto mlft-0 mrt-0">
    <section class="col-md-12 pt-0 pb-0 clearfix">
        <div class="float-left pt-3">
            <small class="d-block mt-3  mb-3 text-muted">&copy; <?=date('Y') ?> Stark &middot;             <span>
                made with <span class="fa fa-heart"></span> by <a href="http://laererlabs.tk" class="text-white" target="_blank">L&aelig;rer Labs</a>
            </span></small>
        </div>
        <!-- <div class="float-right mt-3 pt-3" id="ytWidget"></div> -->
        <ul class="nav float-right mt-3 pt-3">
            <li class="nav-item">
                <a class="nav-link text-hover-white" href="#">Terms</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-hover-white" href="#">Privacy</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-hover-white" href="#">Affiliates</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-hover-white" href="#">Contact</a>
            </li>
        </ul>
    </section>
</div>