<?php 
 $pg = basename($_SERVER['PHP_SELF']);;
 if($pg == 'index.php' || $pg == 'default.php'){
?>
<div id="bannerSlide" class="carousel slide px-0 mx-0 my-0 pt-3 mb-3" data-pause="hover" data-interval="5000"
    data-keyboard="true" data-touch="true" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="./assets/images/1.jpg" class="d-block w-100" alt="..." />
            <div class="carousel-caption px-3 py-3">
                <h5 class="text-left display-5">How to Fill text around an object using Inkscapel</h5>
                <p class="text-left text-light">
                    <p class="text-light" id="meta">
                        By <a href="#">Mosh Hamedhani</a> &middot; <a href="#">Artificial Intelligence</a> &middot;
                        three days ago.
                    </p>
                    <p id="description">
                        Grab the Bezier Pen and manually create a green tracing of the object(s) you’d like the text to
                        avoid. It doesn’t have to be green, I just chose green because it contrasts with the image so
                        that I could see it better....</p>
                    <p class="text-md-right"><a href="#" class="btn btn-primary">START LEARNING</a></p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="./assets/images/2.jpg" class="d-block w-100" alt="..." />
            <div class="carousel-caption px-3 py-3">
                <h5 class="text-left display-5">How to Fill text around an object using Inkscapel</h5>
                <p class="text-left text-light">
                    <p class="text-light" id="meta">
                        By <a href="#">Mosh Hamedhani</a> &middot; <a href="#">Artificial Intelligence</a> &middot;
                        three days ago.
                    </p>
                    <p id="description">
                        Grab the Bezier Pen and manually create a green tracing of the object(s) you’d like the text to
                        avoid. It doesn’t have to be green, I just chose green because it contrasts with the image so
                        that I could see it better....</p>
                    <p class="text-md-right"><a href="#" class="btn btn-primary">START LEARNING</a></p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="./assets/images/3.jpg" class="d-block w-100" alt="..." />
            <div class="carousel-caption px-3 py-3">
                <h5 class="text-left display-5">How to Fill text around an object using Inkscapel</h5>
                <p class="text-left text-light">
                    <p class="text-light" id="meta">
                        By <a href="#">Mosh Hamedhani</a> &middot; <a href="#">Artificial Intelligence</a> &middot;
                        three days ago.
                    </p>
                    <p id="description">
                        Grab the Bezier Pen and manually create a green tracing of the object(s) you’d like the text to
                        avoid. It doesn’t have to be green, I just chose green because it contrasts with the image so
                        that I could see it better....</p>
                    <p class="text-md-right"><a href="#" class="btn btn-primary">START LEARNING</a></p>
            </div>
        </div>
    </div>
</div>
<?php 
 }
 else{
 ?>
<div class="lead bcsitemap" aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Library</li>
    </ol>
</div>
<?php    
 }
?>