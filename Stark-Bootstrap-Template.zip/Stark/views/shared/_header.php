<nav class="navbar navbar-expand-lg navbar-primary mx-auto main-menu">
    <a class="navbar-brand text-white font-weight-bolder" href="./index">
        Stark
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#topmenu"
        aria-controls="topmenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="fa fa-bars border-0 shadow-none text-info"></span>
    </button>
    <div class="collapse navbar-collapse" id="topmenu">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link text-white" href="./index">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="./elements">Elements</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="./error">Error</a>
            </li>
            <li class="nav-item dropdown course-menu">
                <a class="nav-link text-white dropdown-toggle" href="#" id="coursemenu" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Mega Menu
                </a>
                <div class="dropdown-menu shadow c-menu" aria-labelledby="coursemenu">
                    <section class="container-fluid">
                        <div class="row">
                            <section class="col-md-4">
                              <h4 class="font-weight-light text-primary mt-3 mb-3">Categories</h3>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..." data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..." data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..." data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <div class="dropdown-divider"></div>
                              <p class="lead text-right">
                                  <a class="dropdown-menu-item badge badge-primary" href="#">more &raquo;</a>
                              </p>
                            </section>
                            <div class="divider-vert" data-content="&bull;"></div>
                            <section class="col-md-4">
                              <h4 class="font-weight-light text-primary mt-3 mb-3">Genres</h3>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <a href="#" class="mr-1">
                                  <img src="./assets/images/2.jpg" class="mr-0 valign-middle img-thumbnail"
                                      style="width: 75px; height: 75px;" alt="..."  data-toggle="tooltip" data-placement="top" title="Tooltip on top"/>
                              </a>
                              <div class="dropdown-divider"></div>
                              <p class="lead text-right">
                                  <a class="dropdown-menu-item badge badge-primary" href="#">more &raquo;</a>
                              </p>
                            </section>
                            <div class="divider-vert" data-content="&bull;"></div>
                            <section class="col-md-4 bg-course">
                                <h4 class="font-weight-light text-primary mt-3 mb-3">
                                    <span class="fa fa-certiicate mr-2"></span>Press Releases
                                </h3>
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item"><a href="#">Cras justo odio</a></li>
                                    <li class="list-group-item">Dapibus ac facilisis in</li>
                                    <li class="list-group-item">Morbi leo risus</li>
                                    <li class="list-group-item">Porta ac consectetur ac</li>
                                    <li class="list-group-item">Vestibulum at eros</li>
                                </ul>
                                <div class="dropdown-divider"></div>
                                <p class="lead text-right">
                                    <a class="dropdown-menu-item badge badge-primary" href="#">more &raquo;</a>
                                </p>
                            </section>
                        </div>
                    </section>
                </div>
            </li>
        </ul>
        <div class="mt-2 ml-auto">
          <a href="#" class="btn btn-info" role="button" data-toggle="collapse" data-target="#searchbox" aria-expanded="false" aria-controls="searchbox">
            <span class="fa fa-search mr-2"></span>Search
          </a>
          <a href="#" class="btn btn-success" role="button" data-toggle="collapse" data-target="#signinbox" aria-expanded="false" aria-controls="signinbox">
            <span class="fa fa-user mr-2"></span>Signin / Signup
          </a> 
        </div>
    </div>
</nav>
<div class="collapse" id="searchbox">
  <div class="input-group mb-3">
    <input type="search" class="form-control" placeholder="Enter Keyword(s)"/>
    <div class="input-group-append">
      <button class="btn btn-primary" type="button"><span class="fa fa-search"></span></button>
    </div>
  </div>
</div>
<div class="collapse" id="signinbox">
  <form class="form-inline">
    <label class="sr-only" for="username">Username</label>
    <div class="input-group mb-2 mr-sm-2">
      <div class="input-group-prepend">
        <div class="input-group-text bg-primary text-white">@</div>
      </div>
      <input type="text" class="form-control" id="username" placeholder="Username">
    </div>
    <label class="sr-only" for="password">Password</label>
    <div class="input-group mb-2 mr-sm-2">
      <div class="input-group-prepend">
        <div class="input-group-text bg-primary text-white"><span class="fa fa-asterisk"></span></div>
      </div>
      <input type="text" class="form-control" id="password" placeholder="Password">
    </div>
    <div class="form-check mb-2 mr-sm-2">
      <input class="form-check-input" type="checkbox" id="rem">
      <label class="form-check-label text-white" for="rem">
        Stay Signed in
      </label>
    </div>
    <button type="submit" class="btn btn-success mb-2">Login</button>
  </form>
</div>