<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <title>Error &ndash; Stark Bootstrap Template</title>
    <?php require("./views/shared/_meta.php"); ?>
</head>
<body oncontextmenu="return false;">
    <?php require("./views/shared/_nojs.php"); ?>
    <header class="container px-2 bg-primary shadow">
        <?php require("./views/shared/_header.php"); ?>
    </header>
    <main class="container bg-white shadow">
       <?php require("./views/shared/_error.php"); ?>
    </main>
    <footer class="container mt-0 px-2">
        <?php require("./views/shared/_footer.php"); ?>
    </footer>
    <?php require("./views/shared/_scripts.php"); ?>
</body>
</html>